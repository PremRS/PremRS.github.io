A Pen created at CodePen.io. You can find this one at https://codepen.io/Molano/pen/QwmBqR.

 More information coming on [my blog](http://demosthenes.info) presently. Uses SymbolSet's excellent [Social Circle](http://symbolset.com/icons/social-circle) semantic ligature icon fonts for icons; return of the hamburger icon bars still needs a little work.

Forked from [Dudley Storey](http://codepen.io/dudleystorey/)'s Pen [Radial Pop-Out Navigation](http://codepen.io/dudleystorey/pen/emVqYR/).