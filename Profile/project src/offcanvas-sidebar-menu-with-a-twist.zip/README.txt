A Pen created at CodePen.io. You can find this one at https://codepen.io/devilishalchemist/pen/LERvpM.

 Idea and inspiration: https://dribbble.com/shots/1719325-GIF-Sticker-App

Developed in Chrome, not tested elsewhere, not production ready.

Known issue: content overflow is cut when rotated. Tried different pure-CSS solutions and none worked for me. Will give credit for a non-JS solution.

Menu items will flow out of container given window height below roughly 700px. Solved by media queries, can't be bothered to implement it here.